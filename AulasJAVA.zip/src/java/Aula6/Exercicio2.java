public class Exercicio2 {
    public static void main(String[] args) {

        int clima = 0;

        if (clima < 0){
            System.out.println("Congelando!");
        } else if ((clima >= 0) && (clima <= 15)){
            System.out.println("Frio");
        } else if ((clima >= 16) && (clima <= 25)) {
            System.out.println("Agradável");
        } else if ((clima >= 26) && (clima <= 35)){
            System.out.println("Quente");
        } else {
            System.out.println("Inferno!");
        }


    }
}
