import java.util.Scanner;

public class Exercicio7 {
    public static void main(String[] args) {
        double valordacompra = 0;
        double desconto = 0;
        double valorfinal = 0;

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o valor da compra: ");
        valordacompra = sc.nextDouble();

        if ((valordacompra >= 0) && (valordacompra <= 100)){
            valorfinal = valordacompra;
            System.out.println("Você pagará: " + valorfinal);

        } else if ((valordacompra > 100) && (valordacompra <= 300)){
            desconto = (valordacompra * 0.05);
            valorfinal = (valordacompra - desconto);
            System.out.println("Você pagará: " + valorfinal);

        } else if ((valordacompra > 300) && (valordacompra <= 500)){
            desconto = (valordacompra * 0.10);
            valorfinal = (valordacompra - desconto);
            System.out.println("Você pagará: " + valorfinal);

        } else if (valordacompra > 500){
            desconto = (valordacompra * 0.15);
            valorfinal = (valordacompra - desconto);
            System.out.println("Você pagará: " + valorfinal);
        } else {
            System.out.println("Valor inválido!");
        }
    }
}
