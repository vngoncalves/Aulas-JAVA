public class Segundocodigo {
    public static void main(String[] args) {

        int numero = 0;

        if (numero > 0){
            System.out.println("Numero positivo.");
        } else if (numero < 0) {
            System.out.println("Numero negativo.");
        } else {
            System.out.println("Número 0");
        }

        }
}
