public class Exercicio1 {
    public static void main(String[] args) {

        int idade = 0;

        if (idade < 10){
            System.out.println("Desenho animado");
        } else if ((idade >= 10) && (idade <= 12)){
            System.out.println("Filme infantil");
        } else if ((idade >= 13) && (idade <= 17)) {
            System.out.println("Desenho adolescente");
        } else {
            System.out.println("Filme adulto");
        }

    }
}
