public class Exercicio4 {
    public static void main(String[] args) {
        int pontuacao = 10;

        if ((pontuacao >= 0) && (pontuacao < 1000)) {
            System.out.println("Bronze");
        } else if ((pontuacao >= 1000) && (pontuacao < 5000)){
            System.out.println("Prata");
        } else if ((pontuacao >= 5000) && (pontuacao < 10000)){
            System.out.println("Ouro");
        } else if ((pontuacao >= 10000) && (pontuacao < 20000)){
            System.out.println("Platina");
        } else if (pontuacao > 20000){
            System.out.println("Lendário");
        } else {
            System.err.println("Trapaça detectada!");
        }
    }
}
