import java.util.Scanner;

public class Exercicio5 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        System.err.println("Digite a cor do semáforo:");
        String cor = sc.nextLine();

        if (cor.equalsIgnoreCase("verde")){
            System.err.println("Pode passar");

        } else if (cor.equalsIgnoreCase("amarelo")){
            System.err.println("Atenção. reduza!");

        } else if (cor.equalsIgnoreCase("vermelho")){
            System.err.println("Pare!");
            
        } else {
            System.err.println("Cor inválida!");
        }
    }
}
