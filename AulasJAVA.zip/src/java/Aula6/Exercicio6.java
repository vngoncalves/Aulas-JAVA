import java.util.Scanner;

public class Exercicio6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double saldo = 0;
        double saque = 0;
        double saldoatual = 0;

        System.out.println("Digite o valor do seu saldo:");
        saldo = sc.nextDouble();

        System.out.println("Digite o valor que deseja sacar:");
        saque = sc.nextDouble();

        if (saque > saldo){
            System.out.println("Saldo insuficiente!");
        } else if (saque < 0){
            System.out.println("Valor inválido.");
        } else if (saque > 1000){
            System.out.println("Saque acima do limite diário.");
        } else {
            saldoatual = (saldo - saque);
            System.out.println("Saque realizado! Novo saldo: R$" + saldoatual);
        }

    }
}
