
import java.util.Scanner;

public class Exercicio3 {

    public static void main(String[] args) {

        double media = 0;

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite a sua 1ª Nota:");
        double n1 = sc.nextDouble();

        System.out.println("Digite a sua 2ª Nota:");
        double n2 = sc.nextDouble();

        System.out.println("Digite a sua 3ª Nota:");
        double n3 = sc.nextDouble();

        media = ((n1 + n2 + n3) / 3);

        if (media >= 7) {
            System.err.println("Aprovado!");
        } else if ((media >= 5) && (media < 7)) {
            System.err.println("Em recuperação");

            System.err.println("Digite a nota de recuperação:");
            double recuperacao = sc.nextDouble();

            double novamedia = ((media + recuperacao) / 2);

            if (novamedia >= 6){
                System.err.println("Aprovado na recuperação!");
            } else {
                System.err.println("Reprovado.");
            }

        } else {
            System.err.println("Reprovado!");
        }

    }
}
