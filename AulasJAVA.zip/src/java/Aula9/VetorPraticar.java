import java.util.Scanner;

public class VetorPraticar {
    public static void main(String[] args) {
        double [] notas = new double[10];
        int x = 1;
        
        Scanner sc = new Scanner(System.in);
        
        for (int i=0;i<=9;i++){
            System.out.println("Digite a sua " + x + "ª nota: ");
            notas[i] = sc.nextDouble();
            x++;
        }

        for (int i=0;i<=9;i++){
            System.out.println(notas[i]);
        }
    }
}
