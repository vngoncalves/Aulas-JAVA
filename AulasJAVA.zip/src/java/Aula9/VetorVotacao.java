    import java.util.Scanner;

    public class VetorVotacao {
        public static void main(String[] args) {
            String [] votos = new String[3];
            String [] candidatos = {"Agnes", "Jefferson", "Juan", "Nulo"};
            Scanner sc = new Scanner(System.in);
            String eleitor;
            int p = 0;
            int contarvotos = 0;

            System.out.print("O mesário libera a urna?\n- ");
            String mesario = sc.next();

            while (mesario.equalsIgnoreCase("sim") && contarvotos != votos.length){
                for(int i = 0; i < candidatos.length; i++){
        
                    if (i != (candidatos.length - 1)){
                        System.out.print(candidatos[i] + " | ");
                    } else {
                        System.out.print(candidatos[i] + ".");
                    }
                }

            System.out.print("\n\nQual o seu voto?\n- ");
            eleitor = sc.next();

            if (eleitor.equalsIgnoreCase("agnes")){
                votos[p] = "agnes";
                contarvotos++;
            } else if (eleitor.equalsIgnoreCase("juan")){
                votos[p] = "jefferson";
                contarvotos++;    
            } else if (eleitor.equalsIgnoreCase("jefferson")){
                votos[p] = "juan";
                contarvotos++;
            } else {
                votos[p] = "nulo";
                contarvotos++;
            }

            if(contarvotos == votos.length){
                System.out.println("Votação encerrada!");
                break;
            } else {
                System.out.print("O mesário libera a urna?\n- ");
                mesario = sc.next();
            }

            }
        }
    }
