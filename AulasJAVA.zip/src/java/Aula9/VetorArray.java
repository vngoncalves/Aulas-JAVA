    public class VetorArray{
        public static void main(String[] args) {
            String [] nomes = new String[5];
            nomes[0] = "Vinicius";
            nomes[1] = "João";
            nomes[2] = "Marcos";
            nomes[3] = "Victor";
            nomes[4] = "Juan";

            for (int i = 0; i < 4; i++){
                System.out.println(nomes[i]);
            }
        
        }
    }