    public class VetorCarregar {
        public static void main(String[] args) {
            int [] idades = {
                43, 35, 42, 21, 15, 45, 69, 32, 10, 8, 89, 
                25, 43, 35, 42, 21, 15, 45, 
                69, 32, 10, 8, 89, 25, 43, 35, 42, 21, 15, 45, 
                69, 32, 10, 8, 89, 25, 43, 35, 42, 21, 15, 45, 69, 32, 10, 8, 89, 25
            };

            int soma = 0;
            int media = 0;

            for(int i = 0; i < idades.length; i++){
                soma = soma + idades[i];
                media = soma / idades.length;
    }

    System.out.println("Resultado = " + soma);
    System.out.println("Resultado = " + media);
}
}