import java.util.Scanner;

public class EscolaFor {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double notas, acumulador = 0;


        for (int i=1; i<=4; i++){
            System.out.println("Digite a " + i + "ª nota: ");
            notas = sc.nextDouble();
            acumulador = acumulador + notas;
        }

        System.out.println("Soma das notas: " + acumulador);

    
        System.out.println("Deseja partipar?");
        String pergunta = sc.next();
        int contador = 0;

        while (pergunta.equalsIgnoreCase("sim")){

            contador++;

            System.out.println("Deseja partipar?");
            pergunta = sc.next();
        }

        


    }
}
