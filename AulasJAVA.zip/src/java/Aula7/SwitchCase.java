import java.util.Scanner;

public class SwitchCase{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.err.println("Digite um número entre 0 e 6 :");
        int numero = sc.nextInt();

        switch(numero){
            case 0: System.err.println("Domingo");
            break;

            case 1: System.err.println("Segunda");
            break;

            case 2: System.err.println("Terça");
            break;

            case 3: System.err.println("Quarta");
            break;

            case 4: System.err.println("Quinta");
            break;

            case 5: System.err.println("Sexta");
            break;

            case 6: System.err.println("Sábado");
            break;

            default: System.err.println("Opção invalida!");
        }
    }
}