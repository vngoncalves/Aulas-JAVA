public class EstruturaWhile {

    public static void main(String[] args) {
        
        int teste = 1;
        while (teste <= 10) {
            System.out.println("Repetiu While" + teste);

            teste = teste + 1;
            teste++;
        }
        
    }
}
