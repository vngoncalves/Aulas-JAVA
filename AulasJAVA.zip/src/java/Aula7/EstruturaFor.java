public class EstruturaFor {
    public static void main(String[] args){

        for (int i=1; i<10; i++){
            System.out.println("Repetiu For" + i);
        }
    }
}
