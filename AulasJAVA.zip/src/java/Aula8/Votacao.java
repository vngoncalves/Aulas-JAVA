import java.util.Scanner;

public class Votacao {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int jefferson = 0, juan = 0, agnes = 0, brancos = 0, nulos = 0;

        System.out.println("Deseja realizar um voto?");
        String pergunta = sc.next();
        int quantia = 0;



        while(pergunta.equalsIgnoreCase("sim")){
        System.out.println("\nOpções: jefferson(1), juan(2) ou agnes(3), branco(4) ou nulo(5). \nDigite o número do seu candidato:");
        int voto = sc.nextInt();

        if (voto == 1){
                jefferson++;
            } else if (voto == 2) {
                juan++;
            } else if (voto == 3) {
                agnes++;
            } else if (voto == 4) {
                brancos++;
            } else if (voto == 5) {
                nulos++;
            } else {
                System.err.println("Numero inválido!");
            }
        System.out.println("\nVoto realizado com sucesso!\n");
        System.out.println("Apuração: " + "\njefferson = " + jefferson + "\njuan = " + juan + "\nagnes = " + agnes + "\nbrancos = " + brancos + "\nnulos = " + nulos);


        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        /*while (pergunta.equalsIgnoreCase("sim")){

            System.out.println("Em quem você deseja votar, 1 (jefferson), 2 (juan) ou 3 (agnes) ?");
            int voto = sc.nextInt();

            if (voto == 1){
                jefferson++;
            } else if (voto == 2) {
                juan++;
            } else {
                agnes++;
            }

            System.out.println("Voto realizado com sucesso!\n");
            quantia++;
        }*/


        /*for (quantia = 0;quantia <= 3;quantia++){

            System.out.println("Em quem você deseja votar, 1 (jefferson), 2 (juan) ou 3 (agnes) ?");
            int voto = sc.nextInt();

            if (voto == 1){
                jefferson++;
            } else if (voto == 2) {
                juan++;
            } else {
                agnes++;
            }

            System.out.println("Voto realizado com sucesso!\n");
            quantia++;
        }

        System.out.println("Apuração: " + "\njefferson = " + jefferson + "\njuan = " + juan + "\nagnes = " + agnes); */


    }
}
