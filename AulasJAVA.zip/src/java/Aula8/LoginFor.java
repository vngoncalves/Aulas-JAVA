import java.util.Scanner;

public class LoginFor {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String getlogin = "admin", getsenha = "admin";

        for (int tentativas = 3; tentativas >= 1; tentativas--) {

            System.out.println("Digite o seu Login: ");
            String login = sc.next();

            System.out.println("Digite a sua Senha: ");
            String senha = sc.next();

            if (login.equals(getlogin) && senha.equals(getsenha)) {
                System.out.println("Login válido!");

                break;
            } else {
                System.out.println("Login ou senha incorretos. Você tem " + (tentativas - 1) + " tentativas restantes!");
            }
        }
    }
}