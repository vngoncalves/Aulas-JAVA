import java.util.Scanner;

public class TabuadaFor{
    public static void main(String[] args) {
    
        Scanner sc = new Scanner(System.in);

        System.out.println("Escolha um número para iniciar: ");
        int numero = sc.nextInt();
        int i = numero;
        int x = 0;

        while (i <= 10){

            while(x <= 10){

            int resultado = (i * x);
            System.out.println(i + " x " + x + " = " + resultado);
            x++;
            
        }
            i++;
            x = 0;
            
            System.out.println("-----------------------------------");
        }


}
}

