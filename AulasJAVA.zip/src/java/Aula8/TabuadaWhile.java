import java.util.Scanner;

public class TabuadaWhile{
    public static void main(String[] args) {
    
        Scanner sc = new Scanner(System.in);

        System.out.println("Escolha um número para iniciar: ");
        int numero = sc.nextInt();

        for (int i = numero; i <= 10; i++){

            for(int x = 1; x <= 10; x++){

            int resultado = (i * x);
            System.out.println(i + " x " + x + " = " + resultado);
            }
            System.out.println("-----------------------------------");
        }


}
}