package java.Aula5;
public class Terceirocodigo {
    public static void main(String[] args){
        String login = "Admin123";
        String senha = "Admin123";

        /* if (login.equals("Admin123")){
            System.out.println("Login correto!");
        } else {
            System.out.println("Login incorreto.");
        }

        if (senha.equals("Admin123")){
            System.out.println("Login correto!");
        } else {
            System.out.println("Login incorreto.");
        } */

        if (login.equals("Admin123") && (senha.equals("Admin123"))){
            System.out.println("Login válido!");
        } else {
            System.out.println("Login inválido!");
        }

        String termos = "sim";
        if (termos.equalsIgnoreCase("Sim")){
            System.out.println("Termos aceitos!");
        } else {
            System.out.println("Termos não aceitos!");
        }


        


        }
}
