package java.Aula5;
import java.util.Scanner;

public class Quartocodigo {
    public static void main(String[] args){

        String login = "Admin123";
        String senha = "Admin123";

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o seu login:");
        String loginuser = sc.next();

        System.out.println("Digite a sua senha:");
        String senhauser = sc.next();

        if (loginuser.equals(login) && senhauser.equals(senha)){
            System.out.println("Login autorizado!");
        } else {
            System.out.println("Login ou senha incorreto.");
        }
    }
}

