import java.util.Scanner;

public class Primeirocodigo {
    public static void main(String[] args){

        double n1, n2, n3, n4, media = 0;
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite a 1ª Nota:");
        n1 = sc.nextDouble();

        System.out.println("Digite a 2ª Nota:");
        n2 = sc.nextDouble();

        System.out.println("Digite a 3ª Nota:");
        n3 = sc.nextDouble();

        System.out.println("Digite a 4ª Nota:");
        n4 = sc.nextDouble();

        media = ((n1 + n2 + n3 + n4) / 4);
        double frequencia = 80;

        System.out.println("A média é:" + media);

        if ((media >= 7) && (frequencia >= 75)){
            System.out.println("Aluno aprovado!");
        } else {
            System.out.println("Aluno reprovado.");
        }
    }
}