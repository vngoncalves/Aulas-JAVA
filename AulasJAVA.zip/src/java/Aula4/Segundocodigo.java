import java.util.Scanner;

public class Segundocodigo {
    static void main(String[] args) {
        double n1, n2, n3, n4, media = 0;
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite a 1ª Nota:");
        n1 = sc.nextDouble();

        System.out.println("Digite a 2ª Nota:");
        n2 = sc.nextDouble();

        System.out.println("Digite a 3ª Nota:");
        n3 = sc.nextDouble();

        System.out.println("Digite a 4ª Nota:");
        n4 = sc.nextDouble();

        media = ((n1 + n2 + n3 + n4) / 4);

        System.out.println("A média é:" + media);

        if (media >= 7){
            System.out.println("Aluno aprovado!");
        } else if (media < 4){
            System.out.println("Aluno reprovado.");
        } else {
            System.out.println("Aluno em recuperação.");
        }

        
        if (media >= 7){
            System.out.println("Aluno aprovado!");
        } else if ((media >= 4) && (media < 7)){
            System.out.println("Aluno em recuperação.");
        } else {
            System.out.println("Aluno em reprovado.");
        }
    }
}
