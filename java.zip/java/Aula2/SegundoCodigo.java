import java.util.Scanner;

public class SegundoCodigo {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Digite seu nome: ");
        String nome = sc.next();

        System.out.println("Digite a 1ª Nota: ");
        double nota1 = sc.nextDouble();
        System.out.println("Digite a 2ª Nota: ");
        double nota2 = sc.nextDouble();
        System.out.println("Digite a 3ª Nota: ");
        double nota3 = sc.nextDouble();
        System.out.println("Digite a 4ª Nota: ");
        double nota4 = sc.nextDouble();

        System.out.println("Soma das suas notas: " + (nota1 + nota2 + nota3 + nota4));
        System.out.println("A média das suas notas: " + ((nota1 + nota2 + nota3 + nota4)) / 4);
        System.out.println("O seu nome é: " + nome);


        System.out.println("Digite sua altura: ");
        float altura = sc.nextFloat();

        System.out.println("Digite o seu status: ");
        boolean status = sc.nextBoolean();

        System.out.println("Digite sua idade: ");
        int idade = sc.nextInt();

        System.out.println("Aceita os termos do contrato?");
        char aceito = sc.next().charAt(0);
    

        /* 
        float altura = ;
        boolean status = ;
        char aceito = ;
        int idade = ;
        */
    }
}