public class PrimeiroCodigo {
    public static void main(String[] args) {
        // Criar variavel para armazenar
        // o nome do aluno e suas 4 notas
        // somar as 4 notas e calcular a media

        String aluno = "Vinicius Gonçalves";
        double n1 = 10, n2 = 8, n3 = 8, n4 = 10;
        double soma = 0, media = 0;

        // declarar e carregar
        // altura, status, aceito, idade

        float altura = 1.81f;
        boolean status = true;
        char aceito = 'S';
        int idade = 18;

        // Exibir a soma das notas e a média

        soma = n1 + n2 + n3 + n4;
        media = soma / 4;

        System.out.println("Soma das Notas: " + soma);
        System.out.println("Média das Notas: " + media);

        System.out.println("Aluno: " + aluno);
        System.out.println("Altura: " + altura);
        System.out.println("Status: " + status);
        System.out.println("Aceito: " + aceito);
        System.out.println("Idade: " + idade);
    }
}
