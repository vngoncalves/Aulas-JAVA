import java.util.Scanner;
public class TerceiroCodigo{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o 1º Número: ");
        int num1 = sc.nextInt();

        System.out.print("Digite o 2º Número: ");
        int num2 = sc.nextInt();

        // ">" simbolo de maior

        boolean t1 = num1 > num2;
        System.out.println("Teste 1: " + t1);

        boolean t2 = num1 >= num2;
        System.out.println("Teste 2: " + t2);

        boolean t3 = num1 <= num2;
        System.out.println("Teste 3: " + t3);

        boolean t4 = num1 == num2;
        System.out.println("Teste 4: " + t4);

        boolean t5 = num1 != num2;
        System.out.println("Teste 5: " + t5);


    }
}