public class SegundoCodigo {
    public static void main(String[] args) {
        
        int idade = 10;
        String nome = "Vinicius Gonçalves";
        float salario = 5.000f;
        boolean status = true;
        char aceito = 'S';
        double altura = 1.81;

        System.out.println("idade = " + idade);
        System.out.println("nome = " + nome);
        System.out.println("salario = " + salario);
        System.out.println("status = " + status);
        System.out.println("aceito = " + aceito);
        System.out.println("altura = " + altura);
    }
}
