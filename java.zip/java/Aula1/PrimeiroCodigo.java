public class PrimeiroCodigo {
    public static void main(String [] args){
        String nome = "Vinicius Gonçalves ";
        String sobrenome = "Silveira";

        System.out.println(nome + sobrenome);
    };
}
