import java.util.Scanner;

public class PrimeiroCodigo {
    public static void main(String[] args){

        // System.out.print("Teste");
        Scanner sc = new Scanner(System.in);

        // Declarar 3 variáveis do tipo inteiro
        System.out.print("Digite o primeiro número: ");
        int n1 = sc.nextInt();

        System.out.print("Digite o segundo número: ");
        int n2 = sc.nextInt();

        System.out.print("Digite o terceiro número: ");
        int n3 = sc.nextInt();
            System.out.print("\n\n");

        // Declarar 2 variáveis do tipo lógica
        // "simbolo de menor '<' "

        System.out.print("O usuário é verificado?\n(Responda com 'true' ou 'false') : ");
        boolean verificado = sc.nextBoolean();
         System.out.print("\n");

        System.out.print("O usuário é um administrador?\n(Responda com 'true' ou 'false') : ");
        boolean admin = sc.nextBoolean();
        System.out.print("\n");
        System.out.print("------------------------------------------------------\n");


        // Teste 1
        boolean teste = (n1 + n2) > 10 && (n3- n1) < 50;
        System.out.println("Resultado do primeiro teste: " + teste);

        // Teste 2
        teste = (n1 - n2) >= n3;
        System.out.println("Resultado do segundo teste: " + teste);


        // Exercício 1
        teste = (n1 + n2 + n3) < 25;
        System.out.println("Resultado do terceiro teste: " + teste);

        // Exercício 2
        teste = ((n1 + n2 + n3) / n3) < 1;
        System.out.println("Resultado do quarto teste: " + teste);

        // Exercício 3
        teste = (n3 > n1) && (n3 > n2);
        System.out.print("Resultado do sexto teste: " + teste);
        System.out.print("\n\n");

        // Exercício 4
        verificado =! false;
        System.out.println("(Quinto teste) : " + verificado);

        // Exercício 5
        admin =! false;
        System.out.println("(Sexto teste) : " + admin);
}
}